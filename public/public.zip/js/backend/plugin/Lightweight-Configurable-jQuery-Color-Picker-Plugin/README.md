# jQuery / jqLite plugin: ColorPicker ByGiro

jQuery / jqLite plugin to build a lightweight colorpicker


### Install with Bower

```bash
$ bower install jquery-colorpicker-bygiro --save
```

check the demo

(documentation coming soon!)
